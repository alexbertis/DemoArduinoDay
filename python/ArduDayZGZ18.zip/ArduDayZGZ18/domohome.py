import time
import serial.tools.list_ports
import json
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate('alexduino-day-firadmin.json')
app = firebase_admin.initialize_app(cred, {'databaseURL' : 'https://alexduino-day-zgz.firebaseio.com'})
ref = db.reference()
ser = serial.Serial('/dev/ttyUSB0')
#for puerto in serial.tools.list_ports.comports():
#    if puerto.manufacturer == 'wch.cn':
#        ser = serial.Serial(puerto.device)
#        break
time.sleep(10)
while True:
    ss = ref.get()
    stri = str(ss['comedor']['lampara']) + ',' + str(ss['entrada']['lampara']) +',' + str(ss['micuarto']['lampara']) + ',' + str(ss['pasillo']['lampara']) + ',' + str(ss['micuarto']['flexo']) + ','+ str(ss['comedor']['persiana']) + ',' + str(ss['micuarto']['persiana'])
    print(stri)
    ser.write(stri)
    print(ser.read_all())
    time.sleep(2)

