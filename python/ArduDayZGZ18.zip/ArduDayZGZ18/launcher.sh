cd /
cd home/pi/Downloads/ArduDayZGZ18
sudo python domohome.py
cd /
